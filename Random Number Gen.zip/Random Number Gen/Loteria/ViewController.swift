//
//  ViewController.swift
//  Loteria
//
//  Created by Eduardo Szeckir on 2020-07-06.
//  Copyright © 2020 Eduardo Szeckir. All rights reserved.
//

import UIKit

enum GameType: String{
    case one = "One"
    case two = "Two"
    case three = "Three"
    case four = "Four"
    case five = "Five"
    case six = "Six"
}

infix operator >-<
func >-< (totalNumbers: Int, range: Int) -> [Int]{
    var result: [Int] = []
    while result.count < totalNumbers{
        let ran = Int.random(in: 1...range)
        if !result.contains(ran) {
            result.append(ran)
        }
    }
    return result.sorted()
}

class ViewController: UIViewController {
    
    @IBOutlet weak var lbGameType: UILabel!
    @IBOutlet var balls: [UIButton]!
    @IBOutlet weak var slTotalNumber: UISlider!
    @IBOutlet weak var lbRN: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        showNumbers(for: .one)
        slTotalNumber.setValue(1, animated: false)
    }
    
    func showNumbers(for type: GameType){
        lbGameType.text = type.rawValue
        var game: [Int] = []
        switch type{
            case .one:
                lbRN.text = "Random Number"
                game = 1>-<100
                balls[0].isHidden = false
                balls[1].isHidden = true
                balls[2].isHidden = true
                balls[3].isHidden = true
                balls[4].isHidden = true
                balls[5].isHidden = true
            case .two:
                lbRN.text = "Random Numbers"
                game = 2>-<100
                balls[0].isHidden = false
                balls[1].isHidden = false
                balls[2].isHidden = true
                balls[3].isHidden = true
                balls[4].isHidden = true
                balls[5].isHidden = true
            case .three:
                lbRN.text = "Random Numbers"
                game = 3>-<100
                balls[0].isHidden = false
                balls[1].isHidden = false
                balls[2].isHidden = false
                balls[3].isHidden = true
                balls[4].isHidden = true
                balls[5].isHidden = true
            case .four:
                lbRN.text = "Random Numbers"
                game = 4>-<100
                balls[0].isHidden = false
                balls[1].isHidden = false
                balls[2].isHidden = false
                balls[3].isHidden = false
                balls[4].isHidden = true
                balls[5].isHidden = true
            case .five:
                lbRN.text = "Random Numbers"
                game = 5>-<100
                balls[0].isHidden = false
                balls[1].isHidden = false
                balls[2].isHidden = false
                balls[3].isHidden = false
                balls[4].isHidden = false
                balls[5].isHidden = true
            case .six:
                lbRN.text = "Random Numbers"
                game = 6>-<100
                balls[0].isHidden = false
                balls[1].isHidden = false
                balls[2].isHidden = false
                balls[3].isHidden = false
                balls[4].isHidden = false
                balls[5].isHidden = false
        }
        for (i,game) in game.enumerated(){
            balls[i].setTitle("\(game)", for: .normal)
        }
    }

    @IBAction func generateGame() {
        switch Int(slTotalNumber.value) {
        case 0:
            showNumbers(for: .one)
        case 1:
            showNumbers(for: .two)
        case 2:
            showNumbers(for: .three)
        case 3:
            showNumbers(for: .four)
        case 4:
            showNumbers(for: .five)
        default:
            showNumbers(for: .six)
        }
    }
    
}

